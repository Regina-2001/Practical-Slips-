import java.util.*;

public class ObserverPatternDemo {
   public static void main(String[] args) {
      Subject subject = new Subject();

    new HexaObserver(subject);
    new OctalObserver(subject);
    new BinaryObserver(subject);

    Scanner sc= new Scanner(System.in); 
    System.out.println("Enter first number");
    int a= sc.nextInt();
    System.out.println("First state change "+a);
    subject.setState(a);

    System.out.println("");
    
    System.out.println("Enter second number");
    int b = sc.nextInt();
    System.out.println("First state change "+b);
    subject.setState(b);
   }
}