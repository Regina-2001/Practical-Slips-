from django.contrib.auth import login, authenticate  # add to imports
from django.shortcuts import render
from django.http import HttpResponse
from .forms import LoginForm

def login_page(request):
    form =LoginForm()
    message = ''
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = request.POST['username']
            return HttpResponse("Welcome "+user)
        else :
            form=login_page()
            return render(request,'authentication/login.html',{'form':form})
    return render(request, 'authentication/login.html', context={'form': form})

