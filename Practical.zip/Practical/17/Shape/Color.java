public interface Color {
	void fillColor();
}