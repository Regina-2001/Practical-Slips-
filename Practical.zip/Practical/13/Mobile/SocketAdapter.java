
public interface SocketAdapter
{
     public Voltage get240Voltage();
 
     public Voltage get12Voltage();
 
     public Voltage get3VVoltage();
}