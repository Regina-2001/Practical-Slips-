public class Socket
{
 
    public Voltage getVoltage()
    {
        return new Voltage(240); //In India 240 is the default voltage
    }
}