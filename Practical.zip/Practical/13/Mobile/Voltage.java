public class Voltage
{
 
    private int voltage;
 
    public Voltage(int v)
    {
        this.voltage = v;
    }
 
    public int getVolts()
    {
        return voltage;
    }
 
    public void setVolts(int voltage)
    {
        this.voltage = voltage;
    }
 
}